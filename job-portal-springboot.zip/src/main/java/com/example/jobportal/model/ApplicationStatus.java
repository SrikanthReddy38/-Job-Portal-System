package com.example.jobportal.model;

public enum ApplicationStatus {
    APPLIED, REVIEWING, SHORTLISTED, REJECTED, HIRED
}

package com.example.jobportal.model;

public enum Role {
    EMPLOYER, APPLICANT
}

package com.example.jobportal.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.jobportal.model.Job;

public interface JobRepository extends JpaRepository<Job, Long> {
    List<Job> findByTitleContainingIgnoreCaseOrLocationContainingIgnoreCase(String title, String location);
}

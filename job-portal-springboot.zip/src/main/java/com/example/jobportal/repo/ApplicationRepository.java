package com.example.jobportal.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.jobportal.model.JobApplication;
import com.example.jobportal.model.User;

public interface ApplicationRepository extends JpaRepository<JobApplication, Long> {
    List<JobApplication> findByApplicant(User applicant);
}

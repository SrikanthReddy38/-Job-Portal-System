package com.example.jobportal.controller;

import com.example.jobportal.model.Job;
import com.example.jobportal.repo.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private JobRepository jobRepository;

    @GetMapping("/")
    public String home(@RequestParam(value = "q", required = false) String q, Model model, Authentication auth) {
        List<Job> jobs;
        if (q != null && !q.isBlank()) {
            jobs = jobRepository.findByTitleContainingIgnoreCaseOrLocationContainingIgnoreCase(q, q);
        } else {
            jobs = jobRepository.findAll();
        }
        model.addAttribute("jobs", jobs);
        model.addAttribute("q", q == null ? "" : q);
        model.addAttribute("auth", auth);
        return "index";
    }
}

package com.example.jobportal.controller;

import com.example.jobportal.model.Job;
import com.example.jobportal.model.User;
import com.example.jobportal.repo.JobRepository;
import com.example.jobportal.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.Optional;

@Controller
@RequestMapping("/employer")
public class JobController {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/jobs/new")
    public String newJob(Model model) {
        model.addAttribute("job", new Job());
        return "employer-job-form";
    }

    @PostMapping("/jobs")
    public String createJob(@Valid @ModelAttribute("job") Job job, BindingResult result, Authentication auth) {
        if (result.hasErrors()) {
            return "employer-job-form";
        }
        Optional<User> employer = userRepository.findByEmail(auth.getName());
        employer.ifPresent(job::setEmployer);
        jobRepository.save(job);
        return "redirect:/";
    }

    @GetMapping("/jobs/{id}/delete")
    public String deleteJob(@PathVariable Long id, Authentication auth) {
        jobRepository.findById(id).ifPresent(job -> {
            if (job.getEmployer() != null && job.getEmployer().getEmail().equals(auth.getName())) {
                jobRepository.delete(job);
            }
        });
        return "redirect:/";
    }
}

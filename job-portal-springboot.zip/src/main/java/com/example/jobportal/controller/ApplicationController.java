package com.example.jobportal.controller;

import com.example.jobportal.model.*;
import com.example.jobportal.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class ApplicationController {

    @Autowired
    private JobRepository jobRepository;
    @Autowired
    private ApplicationRepository applicationRepository;
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/jobs/{id}")
    public String viewJob(@PathVariable Long id, Model model) {
        Job job = jobRepository.findById(id).orElse(null);
        model.addAttribute("job", job);
        return "job-detail";
    }

    @PostMapping("/jobs/{id}/apply")
    public String apply(@PathVariable Long id, @RequestParam String coverLetter, Authentication auth) {
        Job job = jobRepository.findById(id).orElse(null);
        if (job == null) return "redirect:/";
        User applicant = userRepository.findByEmail(auth.getName()).orElse(null);
        if (applicant == null) return "redirect:/login";
        JobApplication app = new JobApplication();
        app.setJob(job);
        app.setApplicant(applicant);
        app.setCoverLetter(coverLetter);
        applicationRepository.save(app);
        return "redirect:/applicant/applications";
    }

    @GetMapping("/applicant/applications")
    public String myApplications(Authentication auth, Model model) {
        User applicant = userRepository.findByEmail(auth.getName()).orElse(null);
        List<JobApplication> apps = applicationRepository.findByApplicant(applicant);
        model.addAttribute("apps", apps);
        return "applicant-applications";
    }
}
